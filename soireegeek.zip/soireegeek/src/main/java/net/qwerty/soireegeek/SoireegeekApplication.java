package net.qwerty.soireegeek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoireegeekApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoireegeekApplication.class, args);
	}

}
